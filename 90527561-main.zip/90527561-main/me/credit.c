#include <cs50.h>
#include <stdio.h>
#include <string.h>

// Function to calculate the checksum using the Luhn algorithm
int luhn_checksum(long card_number)
{
    int sum = 0;
    int double_digit = 0;

    // Process each digit from right to left
    while (card_number > 0)
    {
        int digit = card_number % 10;

        if (double_digit)
        {
            digit *= 2;
            if (digit > 9)
            {
                digit = digit / 10 + digit % 10;
            }
        }

        sum += digit;
        double_digit = !double_digit;
        card_number /= 10;
    }

    return sum;
}

// Function to determine the card type
void determine_card_type(long card_number)
{
    char card_str[20];
    sprintf(card_str, "%ld", card_number);
    int len = strlen(card_str);

    if (len == 15 && (strncmp(card_str, "34", 2) == 0 || strncmp(card_str, "37", 2) == 0))
    {
        printf("AMEX\n");
    }
    else if (len == 16 && (strncmp(card_str, "51", 2) == 0 || strncmp(card_str, "52", 2) == 0 ||
                           strncmp(card_str, "53", 2) == 0 || strncmp(card_str, "54", 2) == 0 ||
                           strncmp(card_str, "55", 2) == 0))
    {
        printf("MASTERCARD\n");
    }
    else if ((len == 13 || len == 16) && card_str[0] == '4')
    {
        printf("VISA\n");
    }
    else
    {
        printf("INVALID\n");
    }
}

int main(void)
{
    // Prompt the user to enter the card number
    long card_number = get_long("Enter card number: ");

    // Calculate the checksum
    int checksum = luhn_checksum(card_number);

    // Validate the checksum
    if (checksum % 10 == 0)
    {
        determine_card_type(card_number);
    }
    else
    {
        printf("INVALID\n");
    }

    return 0;
}
